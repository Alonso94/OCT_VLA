Voided 2026-09-23. These 44 rollouts requested identity tiers (seen 1,2,3,4 /
held-out 0,6 / novel 5) but the pin was exported after the simulator server was
forked, so it never reached the scene: every tier of a checkpoint scored the same
mixed-identity scenes, identical episode by episode. Valid only as unpinned
three-object rollouts. Superseded by the rollouts submitted after commit c31edf3.
